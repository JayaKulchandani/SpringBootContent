package com.example.demoproject.Service;

import com.example.demoproject.Entity.pet;
import com.example.demoproject.Repository.PetRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class PetService {

    @Autowired
    private PetRepository petRepository;

    public pet addPet(pet pet) {
        return petRepository.save(pet);
    }

    public List<pet> getAllPets() {
        return petRepository.findAll();
    }

    public pet getPetById(Integer id) {
        return petRepository.findById(id).orElse(null);
    }

    public pet updatePet(Integer id, pet newPetData) {
        Optional<pet> optionalPet = petRepository.findById(id);
        if (optionalPet.isPresent()) {
            pet existingPet = optionalPet.get();
            existingPet.setName(newPetData.getName());
            existingPet.setBreed(newPetData.getBreed());
            existingPet.setAge(newPetData.getAge());
            existingPet.setPrice(newPetData.getPrice());
            existingPet.setQuantity(newPetData.getQuantity());
            existingPet.setImagePath(newPetData.getImagePath());
            return petRepository.save(existingPet);
        }
        return null;
    }

    public void deletePet(Integer id) {
        petRepository.deleteById(id);
    }
}
