package com.example.demoproject.Service;
import com.example.demoproject.DTO.userdto;
import com.example.demoproject.Entity.User;
import com.example.demoproject.Repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    // Create User
    public User createUser(userdto dto) {
        User user = new User();
        user.setUsername(dto.getName());
        user.setEmail(dto.getEmail());
        user.setPassword(dto.getPassword());
        return userRepository.save(user);
    }

    // Read All Users
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    // Read Single User
    public User getUserById(Long id) {
        return userRepository.findById(id).orElse(null);
    }

    // Update User
    public User updateUser(Long id, userdto dto) {
        Optional<User> optionalUser = userRepository.findById(id);
        if (optionalUser.isPresent()) {
            User user = optionalUser.get();
            user.setUsername(dto.getName());
            user.setEmail(dto.getEmail());
            user.setPassword(dto.getPassword());
            return userRepository.save(user);
        }
        return null;
    }

    // Delete User
    public void deleteUser(Long id) {
        userRepository.deleteById(id);
    }
}
