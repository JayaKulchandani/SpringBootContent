package com.example.demoproject.Repository;
import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demoproject.Entity.pet;

public interface PetRepository extends JpaRepository<pet, Integer> {
}