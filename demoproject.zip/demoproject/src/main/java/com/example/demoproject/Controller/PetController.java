package com.example.demoproject.Controller;

import com.example.demoproject.Entity.pet;
import com.example.demoproject.Service.PetService;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.http.*;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.*;
import java.util.List;

@RestController
@RequestMapping("/pets")
@CrossOrigin(origins = "http://localhost:3000")
public class PetController {

    @Autowired
    private PetService petService;

    @Value("${file.upload-dir}")
    private String uploadDir;

    // Create with optional file upload
    @PostMapping
    public ResponseEntity<pet> addPet(@RequestParam("name") String name,
                                      @RequestParam("age") Integer age,
                                      @RequestParam("breed") String breed,
                                      @RequestParam(value = "file", required = false) MultipartFile file) {

        String fileName = null;

        try {
            if (file != null && !file.isEmpty()) {
                fileName = System.currentTimeMillis() + "_" + StringUtils.cleanPath(file.getOriginalFilename());
                Path uploadPath = Paths.get(uploadDir);
                Files.createDirectories(uploadPath); // Ensure uploads/ folder exists

                Path filePath = uploadPath.resolve(fileName);
                System.out.println("Saving to: " + filePath.toAbsolutePath());

                Files.copy(file.getInputStream(), filePath, StandardCopyOption.REPLACE_EXISTING);
            }

            pet newPet = new pet();
            newPet.setName(name);
            newPet.setAge(age);
            newPet.setBreed(breed);
            newPet.setImagePath(fileName);

            pet savedPet = petService.addPet(newPet);
            return ResponseEntity.ok(savedPet);

        } catch (IOException e) {
            System.err.println("Error saving file: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    // Read all
    @GetMapping
    public List<pet> getAllPets() {
        return petService.getAllPets();
    }

    // Read by ID
    @GetMapping("/{id}")
    public pet getPetById(@PathVariable Integer id) {
        return petService.getPetById(id);
    }

    // Update
    @PutMapping("/{id}")
    public pet updatePet(@PathVariable Integer id, @RequestBody pet pet) {
        return petService.updatePet(id, pet);
    }

    // Delete
    @DeleteMapping("/{id}")
    public String deletePet(@PathVariable Integer id) {
        petService.deletePet(id);
        return "Pet deleted with ID: " + id;
    }

    // Download file
    @GetMapping("/file/{filename:.+}")
    public ResponseEntity<Resource> downloadFile(@PathVariable String filename) throws IOException {
        Path filePath = Paths.get(uploadDir).resolve(filename).normalize();
        Resource resource = new UrlResource(filePath.toUri());

        if (!resource.exists()) {
            return ResponseEntity.notFound().build();
        }

        return ResponseEntity.ok()
                .contentType(MediaType.APPLICATION_OCTET_STREAM)
                .header(HttpHeaders.CONTENT_DISPOSITION,
                        "attachment; filename=\"" + resource.getFilename() + "\"")
                .body(resource);
    }
}
